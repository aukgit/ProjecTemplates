﻿namespace $safeprojectname$.Modules.Message {
    public struct Const {
        #region Error List
      
        #endregion
    }
}