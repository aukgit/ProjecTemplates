﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace $safeprojectname$.Modules.DevUser {
    public static class RegistrationCustomCode {
        public static void CompletionBefore(long userId, bool getRoleFromRegistration, string role = null) {

        }
        public static void CompletionAfter(long userId, bool getRoleFromRegistration, string role = null) {

        }
    }
}