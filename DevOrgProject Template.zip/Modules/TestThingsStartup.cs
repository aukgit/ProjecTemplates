﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace $safeprojectname$.Modules {
    public static class TestThingsStartup {
        public static void BeforeLoadingMain (){
            string hash = DevHash.Get("hello ", null, new string[] { "hello, hi" }, null);
            string o = hash;
        }
  
        public static void AfterLoadingMain() {

        }


    }
}