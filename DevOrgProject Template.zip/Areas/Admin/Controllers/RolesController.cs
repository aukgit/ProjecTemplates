﻿using $safeprojectname$.Models.Context;
using $safeprojectname$.Models.POCO.Identity;
using $safeprojectname$.Modules.DevUser;
using $safeprojectname$.Modules.Role;
using System.Web.Mvc;
using System.Linq;
namespace $safeprojectname$.Areas.Admin.Controllers {
    public class RolesController : Controller {
        private readonly ApplicationDbContext db = new ApplicationDbContext();

        public ActionResult Index() {
            var Roles = RoleManager.GetRoles();
            return View(Roles);
        }



        public ActionResult Create() {
            ViewBag.Max = RoleManager.GetRoles().Max(n => n.PriorityLevel);
            return View();
        }

        [HttpPost]
        public ActionResult Create(ApplicationRole role) {
            if (ModelState.IsValid) {
                db.Entry(role).State = System.Data.Entity.EntityState.Added;
                if (db.SaveChanges() > -1) {
                    return RedirectToAction("Index");
                }
            }

            var error = AppConfig.GetNewErrorCollector();
            error.Add("Not a valid form.");
            AppConfig.SetGlobalError(error);
            return View(role);
        }

        public ActionResult Edit(long id) {
            var role = RoleManager.GetRole(id);
            return View(role);
        }

        [HttpPost]
        public ActionResult Edit(ApplicationRole role) {
            if (ModelState.IsValid) {
                db.Entry(role).State = System.Data.Entity.EntityState.Modified;
                if (db.SaveChanges() > -1) {
                    return RedirectToAction("Index");
                }
            }

            var error = AppConfig.GetNewErrorCollector();
            error.Add("Not a valid form.");
            AppConfig.SetGlobalError(error);
            return View(role);
        }

        public ActionResult Delete(long id) {
            var relatedUsers = RoleManager.GetUsersInRole(id);
            if (relatedUsers != null && relatedUsers.Count() > 0) {
                ViewBag.RoleID = id;
                return View(relatedUsers);
            } else {
                RoleManager.RemoveRole(id);
            }
            return RedirectToActionPermanent("Index");
            //var users = UserManager.GetEveryUser();
            //return View(users);
        }

        public ActionResult DeleteConfirmed(long id) {
            var relatedUsers = RoleManager.GetUsersInRole(id);

            if (relatedUsers != null) {
                var role = RoleManager.GetRole(id);
                foreach (var user in relatedUsers) {
                //RoleManager.(id);
                    RoleManager.RemoveUserRole(user, role.Name);
                }
                RoleManager.RemoveRole(id);
            }
            return RedirectToActionPermanent("Index");
        }


    }
}
