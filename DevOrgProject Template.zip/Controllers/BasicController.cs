﻿using $safeprojectname$.Models.Context;
using $safeprojectname$.Modules.UserError;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace $safeprojectname$.Controllers {
    public abstract class BasicController : Controller {
        public readonly ApplicationDbContext db;
        public ErrorCollector _errorCollector;
        public BasicController() {

        }
        public BasicController(bool applicationDbContextRequried) {
            if (applicationDbContextRequried) {
                db = new ApplicationDbContext();
            }
        }
        public BasicController(bool applicationDbContextRequried, bool errorCollectorRequried) {
            if (errorCollectorRequried) {
                _errorCollector = new ErrorCollector();
            }
            if (applicationDbContextRequried) {
                db = new ApplicationDbContext();
            }
        }
        protected override void Dispose(bool disposing) {
            if (db != null) {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}