﻿using $safeprojectname$.Models.DesignPattern.Interfaces;
using $safeprojectname$.Models.POCO.IdentityCustomization;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Security.Claims;
using System.Threading.Tasks;

namespace $safeprojectname$.Models.POCO.Identity
{
    public class ApplicationUser : IdentityUser<long, ApplicationUserLogin, ApplicationUserRole, ApplicationUserClaim>, IDevUser
    {

        #region Generate User
        public async Task<ClaimsIdentity> GenerateUserIdentityAsync(ApplicationUserManager manager)
        {
            // Note the authenticationType must match the one defined in CookieAuthenticationOptions.AuthenticationType
            var userIdentity = await manager.CreateIdentityAsync(this, DefaultAuthenticationTypes.ApplicationCookie);
            // Add custom user claims here
            return userIdentity;
        }
        #endregion

        #region Additional Properties with User
        [Column(TypeName = "VARCHAR")]
        [StringLength(15)]
        [Display(Name = "First Name")]
        [Required]
        public string FirstName { get; set; }
        [Column(TypeName = "VARCHAR")]
        [Display(Name = "Last Name")]
        [StringLength(15)]
        [Required]
        public string LastName { get; set; }

        [Display(Name="Name")]
        public string DisplayName
        {
            get
            {
                return FirstName + " " + LastName;
            }
        }

        [Required]

        [Column(TypeName = "date")]
        public DateTime DateOfBirth { get; set; }
        [Column(TypeName = "smalldatetime")]
        public DateTime CreatedDate { get; set; }

        public bool IsRegistrationComplete { get; set; }

        public int CountryID { get; set; }
        public int CountryLanguageID { get; set; }

        public int UserTimeZoneID { get; set; }


        [ForeignKey("UserID")]
        public virtual ICollection<RegisterCodeUserRelation> RegisterCodeUserRelations { get; set; }

        public Guid? GeneratedGuid { get; set; }

        #endregion

       

        //returns user Id
        public long UserID {
            get { return base.Id; }
        }
    }
}