﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace $safeprojectname$.Models.EntityModel.Structs {
    public struct PlatformIDs {
        public const int iOS = 1;
        public const int Android = 2;
        public const int Windows = 3;
        public const int FireFoxOS = 4;
        public const int Other = 5;
    }
}