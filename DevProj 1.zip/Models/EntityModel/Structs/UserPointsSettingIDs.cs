﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace $safeprojectname$.Models.EntityModel.Structs {
    public struct UserPointsSettingIDs {
        public const int PostApp = 1;
        public const int ReviewApp = 2;
        public const int ReviewLiked = 3;
    }
}