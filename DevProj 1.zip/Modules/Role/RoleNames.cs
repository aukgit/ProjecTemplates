﻿namespace $safeprojectname$.Modules.Role {
    public struct RoleNames {
        public static readonly string Admin = "Admin";
    }
}