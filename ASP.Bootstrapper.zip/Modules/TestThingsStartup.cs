﻿namespace $safeprojectname$.Modules {
    public static class TestThingsStartup {
        public static void BeforeLoadingMain() {
        }

        public static void AfterLoadingMain() {
        }
    }
}