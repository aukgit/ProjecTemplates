﻿namespace $safeprojectname$.Models.POCO.IdentityCustomization {
    public class CountryLanguageRelation {
        public int CountryLanguageRelationID { get; set; }
        public int CountryID { get; set; }
        public int CountryLanguageID { get; set; }
    }
}