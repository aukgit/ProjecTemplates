﻿using $safeprojectname$.Models.POCO.Identity;
using $safeprojectname$.Modules.Cache;
using $safeprojectname$.Modules.TimeZone;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;

namespace $safeprojectname$.Modules.Mail {
    public static class MailHtml {

        #region Declaration
        const int _len = 10000;
        const string _defaultMailConfirmBody = "We are very delighted to have you in our website. <a href='{0}' title='{1}'>Here</a> is the <a href='{0}' title='{1}'>link</a> to active your account.<br> Raw : {2} <br><br>";


        static StringBuilder _sb = new StringBuilder(_len);
        #endregion

        #region HTMl Tag Constants
        const string _lineBreak = "<br>";

        const string _h1 = "<h1 style='{0}' title='{1}'>{2}</h1>";
        const string _h2 = "<h2 style='{0}' title='{1}'>{2}</h2>";
        const string _h3 = "<h3 style='{0}' title='{1}'>{2}</h3>";
        const string _h4 = "<h4 style='{0}' title='{1}'>{2}</h4>";

        const string _div = "<div style='{0}' title='{1}'>{2}</div>";

        const string _span = "<span style='{0}' title='{1}'>{2}</span>";
        const string _strong = "<strong style='{0}' title='{1}'>{2}</strong>";
        #endregion

        public static string ThanksFooter(string footerSenderName, string department) {
            string s = string.Format(_lineBreak + _div, "", "Thank you", "Thank  you,");
            s += string.Format(_div, "font-size:14px;font-weight:bold;", "", footerSenderName);
            s += string.Format(_div, "", "Department", department);
            s += string.Format(_div, "", AppVar.Name, AppVar.Name);
            s += string.Format(_div, "", AppVar.Subtitle, AppVar.Subtitle);
            return s;
        }
        public static string EmailConfirm(ApplicationUser user, string callBackUrl, string footerSenderName = "", string department ="Administration", string body = null) {
            _sb.Clear();
            if (body == null) {
                body = string.Format(_defaultMailConfirmBody, callBackUrl, "Link to active account at " + AppVar.Name, callBackUrl);
            }
            _sb.AppendLine("Hello " + user.LastName + ", <br>");
            _sb.AppendLine(_lineBreak);
            _sb.AppendLine(body);
            _sb.AppendLine(_lineBreak);
            _sb.AppendLine(string.Format(_div, "", "", "ID : " + user.UserID));
            _sb.AppendLine(string.Format(_div, "", "", "Display name : " + user.DisplayName));
            _sb.AppendLine(string.Format(_div, "", "", "Login(username) : " + user.UserName));
            _sb.AppendLine(string.Format(_div, "", "", "Email : " +user.Email));
            _sb.AppendLine(string.Format(_div, "", "", "Phone : " + user.PhoneNumber));
            _sb.AppendLine(string.Format(_div, "", "","Timezone : " + CachedQueriedData.GetTimezone(user).UTCName));
            _sb.AppendLine(string.Format(_div, "","" , "Country : "+CachedQueriedData.GetCountry(user).CountryName));
            _sb.AppendLine(_lineBreak);
            _sb.AppendLine(ThanksFooter(AppVar.Setting.AdminName,department));
            return _sb.ToString();
        }
    }
}